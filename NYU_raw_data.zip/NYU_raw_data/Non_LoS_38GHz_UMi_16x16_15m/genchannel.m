clear all;
clc;
DirPDPInfo=dlmread('DirPDPInfo.txt');
M=DirPDPInfo;
T=50; %ns  - narrowband
W=1/T; %GHz
Na=16;
Ne=16;
Ua=dftmtx(Na)/sqrt(Na);
Ue=dftmtx(Ne)/sqrt(Ne);
L=1; % make even
d=[];
Nit=100;
tic
ls=zeros(Na,Ne*L,Nit);
s=[];
del=[];
teA=[];
teE=[];
coord=[];
scal=sqrt(Na*Ne/5.2667e-05); 
s_values=0;
for i=1:1:Nit
   ind=find(M(:,1)==i);
   G=M(ind,:);
   P=M(ind,4);
   d=M(ind,3);
   P=10.^(P/10);
   dmean=sum(P.*d)/sum(P);
   diffsq=(d-dmean).^2;
   drms=sum(P.*diffsq)/sum(P);
   del=[del,sqrt(drms)];

   tm=([0:1:L-1]*T);
   tm=tm-mean(tm)+dmean-(T/2);  
   Z=zeros(Na*Ne,L);
   for k=1:1:length(ind)
        pulse=1;%sinc(W*(tm-G(k,3)));
        pulse=1;%pulse/norm(pulse);
        theta_d=pi*G(k,6)/180; % in rad
        theta_a=pi*G(k,8)/180;
        
        Tmp=exp(1i*pi*sin(theta_a)*[1:1:Na].')*exp(1i*pi*sin(theta_d)*[1:1:Ne]);
        
        Tmp=Tmp*sqrt(10^(G(k,4)/10))*exp(1i*G(k,5));
        Z=Z+(vec(Tmp)*pulse);
   end
   H=reshape(Z,[Na,Ne]);
   s=[s,norm(H,'fro')^2];
   H=H*sqrt(Na*Ne)/norm(H,'fro');
   dlmwrite(strcat('Real_H_',num2str(i),'.csv'),real(H));
   dlmwrite(strcat('Imag_H_',num2str(i),'.csv'),imag(H));
   Spectrum=abs(fft2(H));
   [~,ind]=max(Spectrum(:));
   [~,bv,~]=svd(Spectrum);
   bv=diag(bv);
   s_values=s_values+(bv/bv(1));
   [xind,yind]=ind2sub([Ne,Na],ind);
   coord=[coord;[xind,yind]];
end
%dlmwrite('channelscalings.txt',s)
toc